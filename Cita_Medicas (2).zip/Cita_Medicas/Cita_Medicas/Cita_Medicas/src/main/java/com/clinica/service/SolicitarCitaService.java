package com.clinica.service;

import com.clinica.domain.SolicitarCita;

public interface SolicitarCitaService {

    void guardarCita(SolicitarCita cita);
}