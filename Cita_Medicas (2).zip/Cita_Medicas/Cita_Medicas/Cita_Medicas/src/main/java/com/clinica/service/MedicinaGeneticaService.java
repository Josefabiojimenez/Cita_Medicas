package com.clinica.service;

import com.clinica.domain.MedicinaGenetica;
import java.util.List;

public interface MedicinaGeneticaService {
    List<MedicinaGenetica> listarTodo();
}
