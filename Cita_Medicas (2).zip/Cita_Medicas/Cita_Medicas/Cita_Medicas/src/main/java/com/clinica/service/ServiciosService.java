package com.clinica.service;

import com.clinica.domain.Servicios;

public interface ServiciosService {

    void guardarServicio(Servicios servicio);
}