package com.clinica.service;

import com.clinica.domain.Sugerencia;

public interface SugerenciaService {

    void guardarSugerencia(Sugerencia sugerencia);
}
