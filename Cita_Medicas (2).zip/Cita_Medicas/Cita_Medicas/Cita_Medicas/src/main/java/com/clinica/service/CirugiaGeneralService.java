package com.clinica.service;

import com.clinica.domain.CirugiaGeneral;

public interface CirugiaGeneralService {

    void guardarCirugia(CirugiaGeneral cirugia);
}