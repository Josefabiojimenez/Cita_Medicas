package com.clinica.service;

import com.clinica.domain.Presupuesto;

public interface PresupuestoService {
    void guardarPresupuesto(Presupuesto presupuesto);
}
