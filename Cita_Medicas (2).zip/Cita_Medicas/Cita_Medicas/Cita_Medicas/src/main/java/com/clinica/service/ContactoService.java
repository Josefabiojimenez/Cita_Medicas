package com.clinica.service;

import com.clinica.domain.Contacto;

public interface ContactoService {

    void guardarContacto(Contacto contacto);
}