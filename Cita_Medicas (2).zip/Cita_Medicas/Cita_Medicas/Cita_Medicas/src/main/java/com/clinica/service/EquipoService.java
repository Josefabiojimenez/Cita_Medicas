package com.clinica.service;

import com.clinica.domain.Equipo;
import java.util.List;

public interface EquipoService {
    List<Equipo> obtenerEquipos();
}
